defmodule CrossoverLoggerApi.Repo.Migrations.CreateApp do
  use Ecto.Migration

  def change do

    create table(:applogs1) do
      add :log_id, :string
      add :application_id, :string
      add :logger, :string
      add :level, :string
      add :message, :string
    end

  end
end

defmodule CrossoverLoggerApi.Applog do
  use CrossoverLoggerApi.Web, :model
  schema "applogs" do
    field :log_id, :string
    field :application_id, :string
    field :logger, :string
    field :level, :string
    field :message, :string
  end

  def changeset(model, params \\ :empty) do
    model
      |> cast(params, [:log_id, :application_id, :logger, :level, :message])
  end


end

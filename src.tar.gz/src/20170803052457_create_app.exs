defmodule CrossoverLoggerApi.Repo.Migrations.CreateApp do
  use Ecto.Migration

  def change do

   create table(:app1) do
      add :application_id, :string
      add :display_name, :string
      add :application_secret, :string

    end
  end
end

defmodule CrossoverLoggerApi.PageController do
  use CrossoverLoggerApi.Web, :controller

  def index(conn, _params) do
    apps = Repo.all(CrossoverLoggerApi.App)
    json conn, apps
  end
  
   def indexlog(conn, _params) do
    applogs = Repo.all(CrossoverLoggerApi.Applog)
    json conn, applogs
  end
   
  def register(conn, _params) do
     case ExRated.check_rate("register_app", 60000, 60) do
     {:error, _} ->
       json conn |> put_status(:forbidden), %{errors: ["cross the rate limit"] }
     {:ok,_} ->
       IO.puts "rate limit ok"
     end
     res = %{"display_name" => _params["display_name"], "application_id" => random_string(32), "application_secret" => random_string(32)}
     changeset = CrossoverLoggerApi.App.changeset(%CrossoverLoggerApi.App{}, res)
     case Repo.insert(changeset) do
      {:ok, app} ->
        json conn |> put_status(:created), res
      {:error, _changeset} ->
        json conn |> put_status(:bad_request), %{errors: ["unable to create app"] }
    end
  end

  def auth(conn,_params) do
    case ExRated.check_rate("auth_app", 60000, 60) do
     {:error, _} ->
       json conn |> put_status(:forbidden), %{errors: ["cross the rate limit"] }
     {:ok,_} ->
       IO.puts "rate limit ok"
     end
    res = %{}
    auth_string = conn |> get_req_header("authorization")|> List.first
    [id, secret] = String.split(auth_string, ":")
    app = Repo.get_by(CrossoverLoggerApi.App, application_id: id)
    if app.application_secret == secret do
       res = %{"access_token" =>  secret <> ":" <> Integer.to_string(:os.system_time(:milli_seconds))}
       json conn, res
    end
    json conn |> put_status(:unauthorized), %{errors: ["unable to provide access token"] }
  end

  def logmsg(conn, _params) do
    case ExRated.check_rate("log_app", 60000, 60) do
     {:error, _} ->
       json conn |> put_status(:forbidden), %{errors: ["cross the rate limit"] }
     {:ok,_} ->
       IO.puts "rate limit ok"
     end
    auth_string = conn |> get_req_header("authorization")|> List.first
    [secret, timestamp] = String.split(auth_string, ":")
    app = Repo.get_by(CrossoverLoggerApi.App, application_secret: secret)
    if app.application_secret == secret do
       current = :os.system_time(:milli_seconds)
       {prev, _} = Integer.parse(timestamp)
       diff = current - prev
       if diff < 600000 do
         changeset = CrossoverLoggerApi.Applog.changeset(%CrossoverLoggerApi.Applog{}, _params)
         case Repo.insert(changeset) do
            {:ok, app} ->
                   json conn |> put_status(:created), true
           {:error, _changeset} ->
                   json conn |> put_status(:bad_request), false
         end
       end
    end
    json conn |> put_status(:forbidden), false
  end
   
  
  def random_string(length) do
  :crypto.strong_rand_bytes(length) |> Base.url_encode64 |> binary_part(0, length)
  end

end

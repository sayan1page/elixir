defmodule CrossoverLoggerApi.Router do
  use CrossoverLoggerApi.Web, :router

  pipeline :api do
    plug :accepts, ["json"]
  end

  scope "/api/v1", CrossoverLoggerApi do
    pipe_through :api

    get "/applications", PageController, :index
    get "/applogs", PageController, :indexlog
    post "/register", PageController, :register
    post "/auth", PageController, :auth
    post "/log", PageController, :logmsg
     
  end

  # Other scopes may use custom stacks.
  # scope "/api", CrossoverLoggerApi do
  #   pipe_through :api
  # end
end

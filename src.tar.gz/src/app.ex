defmodule CrossoverLoggerApi.App do
  use CrossoverLoggerApi.Web, :model
  schema "apps" do
    field :application_id, :string
    field :display_name, :string
    field :application_secret, :string
  end

  def changeset(model, params \\ :empty) do
    model
      |> cast(params, [:application_id, :display_name, :application_secret])
  end

end
